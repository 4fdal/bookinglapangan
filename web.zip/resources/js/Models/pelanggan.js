export default class Pelanggan {
    constructor({ user_id, alamat }) {
        this.user_id = user_id;
        this.alamat = alamat;
    }
}
